This corpus was created using the Spamassassin public spam corpus. The 20030228 data set was used. Here is a list of the files:
http://spamassassin.apache.org/publiccorpus/20030228_easy_ham.tar.bz2
http://spamassassin.apache.org/publiccorpus/20030228_easy_ham_2.tar.bz2
http://spamassassin.apache.org/publiccorpus/20030228_hard_ham.tar.bz2
http://spamassassin.apache.org/publiccorpus/20030228_spam.tar.bz2
http://spamassassin.apache.org/publiccorpus/20030228_spam_2.tar.bz2

The index file is a list of these email with judgements in arrival date order. The date order was created using the Received: timestamp and if this was not present the Date: field. 
