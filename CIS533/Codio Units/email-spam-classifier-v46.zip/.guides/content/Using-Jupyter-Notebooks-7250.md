<div class="rendered-markdown"><div id="result">
<!-- .guides/load.js pulls in guide text from S3 -->
</div>
