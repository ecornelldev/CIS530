c = get_config()

c.Exchange.course_id = "facial_recognition"
c.Exchange.root = "/tmp/exchange"